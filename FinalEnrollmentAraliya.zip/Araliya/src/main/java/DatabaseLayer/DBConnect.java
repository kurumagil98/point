
package DatabaseLayer;

import java.sql.DriverManager;

/**
 *
 * @author Araliya Alwis
 */
public class DBConnect {
    
}
