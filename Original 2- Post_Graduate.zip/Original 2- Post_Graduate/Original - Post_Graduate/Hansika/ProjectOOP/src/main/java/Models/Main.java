package Models;
import Interface.PostGraduate;

public class Main {
    public static void main(String [] args)
    {
        PostGraduate UI=new PostGraduate();
        UI.show();
        
    }
}
