/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author TOSHIBA
 */
public class Apply_Degree3 {
    
    String Qualification;
    String Institute;
    String Date;
    String Specialization;
     


public Apply_Degree3(String Qualification,String Institute,String Date,String Specialization) {

        this.Qualification=Qualification;
        this.Institute=Institute;
        this.Date=Date;
        this.Specialization=Specialization;
       
    }

    public String getQualification()
    {
        return Qualification;
    }
    
     public String getInstitute()
    {
        return Institute;
    }
     
      public String getDate()
    {
        return Date;
    }
      
    public String getSpecialization()
    {
        return Specialization;
    }
    
    
     
}     