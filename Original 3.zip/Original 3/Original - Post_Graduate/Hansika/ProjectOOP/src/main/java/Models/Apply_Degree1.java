/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author TOSHIBA
 */
public class Apply_Degree1 {
    
    String Name_I;
    String F_Name;
    String Status;
    String NIC;
    String day;
    String month;
    String year;
    String Address;
    String Nationality;
    String M_Status;
    String mobile;
    String r_mobile;
    String E_mail;
 
  public Apply_Degree1(String Name_I,String F_Name,String Status, String NIC,String day, String month,String year, String Address, String Nationality, String M_Status,String mobile,String r_mobile,String E_mail)  
    
  {
  
      this.Name_I=Name_I;
      this.F_Name=F_Name;
      this.Status=Status;
      this.NIC=Name_I;
      this.day=F_Name;
      this.month=Status;
      this.year=Name_I;
      this.Address=F_Name;
      this.Nationality=Status;
      this.M_Status=Name_I;
      this.mobile=F_Name;
      this.r_mobile=Status;
      this.E_mail=Name_I;
     
  }
    
    
   public String getName_I()
    {
        return Name_I;
    }
    
     public String getF_Name()
    {
        return F_Name;
    }
     
      public String getStatus()
    {
        return Status;
    }
    
       public String getNIC()
    {
        return NIC;
    }
    
     public String getday()
    {
        return day;
    }
     
      public String getmonth()
    {
        return month;
    }
    
       public String getyear()
    {
        return year;
    }
    
     public String getAddress()
    {
        return Address;
    }
     
      public String getNationality()
    {
        return Nationality;
    }
     
     public String getM_Status()
    {
        return M_Status;
    }
    
     public String getmobile()
    {
        return mobile;
    }
     
      public String getr_mobile()
    {
        return r_mobile;
    }  
      
       public String getE_mail()
    {
        return E_mail;
    }
    
    
      
      
      
      
      
}

