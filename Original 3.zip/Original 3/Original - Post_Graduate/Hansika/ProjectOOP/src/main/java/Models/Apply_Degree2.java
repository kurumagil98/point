/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author TOSHIBA
 */
public class Apply_Degree2 {
    
    String Qualification;
    String year;
    String university;
    String field;
    String Class;


 public Apply_Degree2(String Qualification,String year,String university,String field,String Class) {

        this.Qualification=Qualification;
        this.year=year;
        this.university=university;
        this.field=field;
        this.Class=Class;
    }

    public String getQualification()
    {
        return Qualification;
    }
    
     public String getyear()
    {
        return year;
    }
     
      public String getuniversity()
    {
        return university;
    }
      
    public String getfield()
    {
        return field;
    }
    
     public String Class()
    {
        return Class;
    }
     
}     