/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author TOSHIBA
 */
public class Apply_Degree4 {
    
    String F_date;
    String T_date;
    String Position;
    String Details;
    
public Apply_Degree4(String F_date,String T_date,String Position,String Details) {

        this.F_date=F_date;
        this.T_date=T_date;
        this.Position=Position;
        this.Details=Details;
       
    }

    public String getF_date()
    {
        return F_date;
    }
    
     public String getT_date()
    {
        return T_date;
    }
     
      public String getPosition()
    {
        return Position;
    }
      
    public String getDetails()
    {
        return Details;
    }
    
    
     
}     
