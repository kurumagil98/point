/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author User
 */
public class assign {
    public String task;
    public assign( String task){
        
        this.task=task; 

    }
    
    public String task(String empId,String tas)
    {
        return tas;
    }
}
